var chai = require('chai');
global.expect = chai.expect;
chai.should();
chai.use(require('chai-things'));
